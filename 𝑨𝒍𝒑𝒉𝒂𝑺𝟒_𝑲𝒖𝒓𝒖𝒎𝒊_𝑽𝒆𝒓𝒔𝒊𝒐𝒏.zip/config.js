/*
  >> Control <<
*/
global.owner = ['6283151568511']
global.namaown = "𝙳𝚛𝚊𝚢"
global.ownername = "dray"
global.packname = "Alpha S4"
global.connect = true // ubah ke false klo mau connect lewat qrcode 
global.antilink = false
global.autotyping = false

/*
  
  >> Payment <<
*/
global.dana = "XXXX"
global.gopay = "XXXX"
global.ovo = "XXXX"
global.qris = "https://files.catbox.moe/5dfafw.jpg"

/*
  >> Message <<
*/
global.mess = {
"ketua": " ⇝ Access Denied \nKhusus Owner",
"prem": "⇝ Access Denied \nBeli Akses Premium Di Owner",
"premium": "⇝ Access Denied \nBeli Akses Premium Di Owner",
"japost": " -- Format Japost Tidak Tersedia -- ",
"rekber": " -- List Rekber Tidak Tersedia -- ",
"owner": " ⇝ Access Denied \nKhusus Owner"
}

/*
  >> MISC <<
*/
global.tele = "t.me/drayoffc"
global.tele2 = "t.me/drayoffc"
global.waMe = "wa.me/6283151568511"
global.tutorialBot = "https://youtube.com/@drayyyxd" // Untuk menggampangkan buyer awam saat beli panel 
global.versionofscript = "8.0"
global.url = "https://files.catbox.moe/i7jxyz.jpg" // buat banner
global.urlbanner = "https://files.catbox.moe/zay0u6.jpg" // buat banner 2
global.url2 = "https://t.me/drayoffc" // isi url bebas buat reply
global.packname = "jel?" // sticker
global.author = "x-trash" // sticker
global.group = "https://whatsapp.com/channel/0029Vaj4X9iAInPuhzUk3v1L" // isi group bebas lu
global.idCH = "120363333509194874@newsletter"
global.xchannel = {
	jid: '120363333509194874@newsletter'
	}
	